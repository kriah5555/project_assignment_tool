from django.db import models
from datetime import datetime   

# Create your models here.
class Employees(models.Model):
    name                = models.CharField(max_length = 30, default='None')
    username            = models.CharField(max_length = 30, default='None',unique=True)
    password            = models.CharField(max_length = 30, default='None')
    emailid             = models.CharField(max_length = 30, default='None') 
    pojession           = models.CharField(max_length = 30, default='None')

STATUS_CHOICES = (('Not assigned','Not assigned'),('Close','Close'),('IN PROGRESS','IN PROGRESS'),('Open','Open'),('In Hold','In Hold'),('Testing','Testing'))
class Project(models.Model):
    project_name        = models.CharField(max_length = 30, default='None',unique=True)
    #employee_name       = models.CharField(max_length = 30, default='None')
    projedct_start_time = models.DateField(default=datetime.now(), blank=True)
    project_end_time    = models.DateField(default=datetime.now(), blank=True) 
    project_status      = models.CharField(max_length = 30, default = 'Not assigned' ,choices = STATUS_CHOICES)


EMPLOYEE_CHOICE     = [(j.name,j.name) for i,j in enumerate(Employees.objects.all())]
PROJETC_NAMES       = [(j.project_name,j.project_name) for i,j in enumerate(Project.objects.all())]


class ProjectAssignment1(models.Model):
    project_name        = models.CharField(max_length = 100, default='None') 
    employee_name       = models.CharField(max_length = 100, default='None') 







