from django.contrib import admin
from .models import Employees,Project,ProjectAssignment1


# Register your models here.
admin.site.register(Employees)
admin.site.register(Project)
admin.site.register(ProjectAssignment1)