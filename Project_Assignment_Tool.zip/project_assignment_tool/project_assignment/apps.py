from django.apps import AppConfig


class ProjectAssignmentConfig(AppConfig):
    name = 'project_assignment'
